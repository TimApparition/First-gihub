#include"zhan.h"


void demon::OUTPUT(int n)                       //��ջ����ǰջ��ǰ������ȥ
{
	ZHAN *p = pHead;
	for (int i = 1; i < n; i++)
	{
		pHead = p->zNext;
		p = p->zNext;
		LONG--;
	}
}
void demon::SHUCHU()                         //���ջ
{
	ZHAN *p = pHead;
	for(int i=0;i<LONG;i++)
	{
		cout << p->date<<" ";
		p = p->zNext;
	}
}
void demon::MAKE()                           //����ջ
{
	ZHAN *p = new ZHAN;
	p->zNext = pHead;
	pHead->zhead = p;
	pHead = p;
	cin >> p->date;
	LONG++;


}
demon::demon()                                //��ʼ���ⶨ�ռ�
{
	pdemon = new ZHAN;
	if (pdemon == NULL)
		cout << "����ʧ��" << endl;
	pHead = pdemon;
	LONG = 0;
}