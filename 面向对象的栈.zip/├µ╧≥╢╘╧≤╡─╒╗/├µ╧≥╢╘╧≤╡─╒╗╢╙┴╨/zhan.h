#pragma once
#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include <tchar.h>

using namespace std;

typedef struct zhan
{
	zhan *zhead;
	zhan *zNext;
	int date;
}ZHAN;
class demon
{
public:
	demon();                       
	void OUTPUT(int n);                    //��ջ
	void SHUCHU();                         //���ջ
	int GETBACK() { return LONG; };        //����ʣ��Ԫ��
	void MAKE();                           //����ջ
private:
	int LONG;
	ZHAN *pHead;
	ZHAN *pdemon;
};